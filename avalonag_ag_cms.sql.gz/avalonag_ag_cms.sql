-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 25, 2019 at 04:31 AM
-- Server version: 10.2.27-MariaDB-log-cll-lve
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `avalonag_ag_cms`
--

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `email`, `amount`, `created_at`) VALUES
(1, 'Test', 'greemapaul18@gmail.com', '50', '2019-10-12 00:18:21'),
(2, 'Test', 'greemapaul18@gmail.com', '12', '2019-10-12 00:19:21'),
(3, 'Test', 'greemapaul18@gmail.com', '200', '2019-10-12 00:19:54'),
(4, 'Test', 'greemapaul18@gmail.com', '150', '2019-10-12 00:22:05'),
(5, 'Test', 'greemapaul18@gmail.com', '70', '2019-10-12 00:23:18'),
(6, 'greema paul', 'greemapaul18@gmail.com', '12', '2019-10-12 00:24:19'),
(7, 'jibin', 'jibin26xyz@gmail.com', '25', '2019-10-22 07:56:10');

--
-- Dumping data for table `home_gallery`
--

INSERT INTO `home_gallery` (`home_gallery_id`, `home_gallery_image1`, `home_gallery_image2`, `home_gallery_image3`, `home_gallery_image4`) VALUES
(14, 'http://www.avalonag.org.nz/assets/images/church_logo_AOG_Avalon.jpg', 'http://www.avalonag.org.nz/assets/images/agtree1.jpg', 'http://www.avalonag.org.nz/assets/images/mission2.jpg', 'http://www.avalonag.org.nz/assets/images/gallery41.JPG');

--
-- Dumping data for table `table_aboutpage`
--

INSERT INTO `table_aboutpage` (`about_id`, `vision_title`, `vision_description`, `mission_title`, `mission_description`, `mission_image`, `vision_image`, `date`, `message`, `history`, `delete_status`) VALUES
(43, 'Our Church Vision', '<p><font face=\"Arial\" style=\"background-color: rgb(247, 247, 247);\">To be a temple in which God will dwell, an awesome place of encounter with Him.</font></p><p><b><font face=\"Arial\">(Eph 2:19-22, Gen 28:10-17)</font></b></p><p><font face=\"Comic Sans MS\"><b><font face=\"Times New Roman\"></font><font face=\"Arial\"></font><br></b></font></p>', 'Our Church Mission', '<div class=\"sermon_text\" style=\"box-sizing: border-box; margin-top: 33px; -webkit-font-smoothing: antialiased; text-shadow: rgba(0, 0, 0, 0.01) 0px 0px 1px; position: relative; color: rgb(124, 124, 124); font-family: Montserrat, sans-serif; background-color: rgb(240, 244, 248);\"><p style=\"color: rgb(0, 0, 0); font-family: Roboto, sans-serif;\"><font face=\"Comic Sans MS\">To love God through worship & obedience, to love people through fellowship & services, outreaching to make disciples of all the nations.</font></p><p style=\"color: rgb(0, 0, 0); font-family: Roboto, sans-serif;\"><span style=\"font-weight: bolder;\"><font face=\"Comic Sans MS\">(Matt 22:37-40; 28:18-20)</font></span></p></div>', 'http://www.avalonag.org.nz/assets/images/vision_image.jpg', 'http://www.avalonag.org.nz/assets/images/vision2.jpg', '2019-10-18 21:53:43', 'A really warm welcome to this awesome place of God\'s living presence by his dynamic Holy Spirit. We are a fellowship of believers of <br>different nationalities who worship God in Spirit and in truth, serve one-another in love and outreach to make disciples of Jesus. We <br>are believing for the presence of God\'s strong power to heal and save and serve him by extending his kingdom in Avalon and beyond.', 'Sunday 1st April 1990 saw Avalon Assembly of God’s first service get underway at the National Film Unit in Avalon. A small team of eager helpers from Takapuna Assembly of God in Auckland assisted on that first Sunday. They were inspired to do the church plant as a result of the Assemblies of God in NZ focus and vision for church planting at that time. In the summer edition of the 1992 NZ Evangel, an article appeared about the first service and ongoing determination to pray their vision in for the Valley and beyond; “The fellowship has been wonderful, the prayer meetings inspiring and there is a sense of anticipation about the future which has filled us with hope.”', 'no');

--
-- Dumping data for table `table_admin`
--

INSERT INTO `table_admin` (`id`, `name`, `email`, `password`, `encrypted_pass`, `verification_key`, `is_email_verified`, `created_date`) VALUES
(111, 'GREEMA PAUL', 'greemapaul18@gmail.com', 'greemu', 'f583cc4d4b43365f0112c81f31d2c8fd8c2167374b48f7547a9b685b5863fd23f583cc4d4b43365f0112c81f31d2c8fd8c2167374b48f7547a9b685b5863fd23greemu', '30aae6e32c4be55c69d620e63accb44a', 'yes', '2019-10-17 10:31:18'),
(112, 'Annu', 'annubaghel0293@gmail.com', 'annu1108', 'a66ac538bf575ca02b7644635df07af3ca4b2a78053a8ece7cfa60c153c49f8ca66ac538bf575ca02b7644635df07af3ca4b2a78053a8ece7cfa60c153c49f8cannu1108', '8dbbb56d81aa7f0c94d1a5e6300a6079', 'yes', '2019-10-17 10:37:24'),
(113, 'jibin', 'jibin26xyz@gmail.com', '123456789', 'a67fe6558bc83e4b1ca613b812156700920ac24e534869d436ada726f7e4a3cba67fe6558bc83e4b1ca613b812156700920ac24e534869d436ada726f7e4a3cb123456789', '5934dd37932cb92c5456a3c603f49106', 'yes', '2019-10-18 19:45:58'),
(114, 'Annu Baghel', 'annubaghel@gmail.com', 'ANNU', '1dcd78639d4845b50862a624d3e213d5e65c452c7ef77886c88686937e2762d11dcd78639d4845b50862a624d3e213d5e65c452c7ef77886c88686937e2762d1ANNU', '79607da526a8c9f5ce20e02d77e36efb', 'yes', '2019-10-20 11:19:18'),
(115, 'Jemshin Abraham', 'jemshin@gmail.com', 'city9191', '905eda1b4363e76d4fabca598427bed781f9118fffc6b349c4c7e9439218ce29905eda1b4363e76d4fabca598427bed781f9118fffc6b349c4c7e9439218ce29city9191', '92b6a08b5aeaabee8f53cf620faf08f1', 'yes', '2019-10-21 21:52:26');

--
-- Dumping data for table `table_contactpage`
--

INSERT INTO `table_contactpage` (`contact_id`, `contact_name`, `contact_address`, `contact_phone`, `contact_email`, `contact_phone2`, `delete_status`) VALUES
(8, 'PO Box 46019, Park Avenue, Lower Hutt, 5044', '  870 High Street, (Corner of High and Daysh Streets), Boulcott, Lower Hutt 5011,\r\n', 45672225, 'avalon.ag@xtra.co.nz', 45627808, 'no');

--
-- Dumping data for table `table_eventpage`
--

INSERT INTO `table_eventpage` (`id`, `event_title`, `event_description`, `image`, `date`, `delete_status`) VALUES
(4, 'Post-service prayer ', '<span style=\"font-size: 12px;\"><b style=\"\"><font face=\"Comic Sans MS\">Pre-service prayer - 10.30 AM&nbsp;</font></b></span>', 'http://www.avalonag.org.nz/assets/images/Pre-service-prayer4.jpg', '2019-10-22', 0),
(10, 'Sunday Service ', '<p><span style=\"font-size: 12px; font-weight: 700;\"><font face=\"Comic Sans MS\">Sunday Service - 10 A', 'http://www.avalonag.org.nz/assets/images/PreServicePrayerImage3.jpg', '2019-10-17', 1),
(11, 'Sunday School', '<p><span style=\"font-size: 12px;\"><font face=\"Comic Sans MS\"><b>Sunday School - 10.30 AM every sunda', 'http://www.avalonag.org.nz/assets/images/children8.jpg', '2019-10-17', 1),
(12, 'healing seminar', '<p>Healing Seminar program</p>', 'http://www.avalonag.org.nz/assets/images/crosses1.jpg', '2019-10-17', 1);

--
-- Dumping data for table `table_home`
--

INSERT INTO `table_home` (`home_id`, `home_title`, `home_description`, `home_image_s1`, `home_image_s2`, `home_image_s3`, `home_wel_image`, `delete_status`, `date`, `Author`) VALUES
(20, 'Welcome to Avalon Assembly of God', '<h3><font face=\"Comic Sans MS\" style=\"background-color: rgb(247, 247, 247);\"><b style=\"\"><span style=\"font-size: 10pt; line-height: 115%;\"> </span><span lang=\"EN-NZ\" style=\"font-size: 10pt; line-height: 115%;\">We are a fellowship of believers of different\r\nnationalities who worship God in Spirit and </span></b><b style=\"font-size: 10pt;\">in truth, serve one-another in love\r\nand outreach to make disciples of Jesus.</b></font></h3>', 'http://www.avalonag.org.nz/assets/images/slider2.jpg', 'http://www.avalonag.org.nz/assets/images/slider3.jpg', 'http://www.avalonag.org.nz/assets/images/slider4.jpg', 'http://www.avalonag.org.nz/assets/images/welcome3.JPG', '', '2019-10-18 21:20:03', '');

--
-- Dumping data for table `table_user_registration`
--

INSERT INTO `table_user_registration` (`register_id`, `user_name`, `user_address`, `user_email`, `user_phone`, `event_id`, `date`) VALUES
(1, 'santhu', '62 colson', 'hfadvkav', '52376878', 4, '2019-10-08 05:24:31'),
(2, 'greema', '62 colson', 'vghfecvj@fgc.svd', '123254365467', 4, '2019-10-08 05:30:46'),
(3, 'santhu', 'wcdae', 'santhoshsebastian555@gmail.com', '23525', 4, '2019-10-08 05:31:57'),
(4, 'santhu', 'wcdae', 'santhoshsebastian555@gmail.com', '23525', 4, '2019-10-08 05:32:20'),
(5, 'ashmy', 'CWRXVEF', 'DSVSD@GFH.SDV', '423432545', 4, '2019-10-09 10:56:54'),
(6, 'ashmy12', 'fcdwgfe', 'AFC@SFD.AFS', '12432534', 4, '2019-10-11 05:54:06'),
(7, 'RUDY', 'dghfgh', 'VBFHG@GMAIL.COM', '657', 12, '2019-10-14 02:44:52'),
(8, 'Greema Paul', '62 Colson Street Avalon', 'greemapaul18@gmail.com', '0226784667', 4, '2019-10-19 12:34:24'),
(9, 'Greema Paul', '62 Colson Street', 'greemapaul18@gmail.com', '0226784667', 4, '2019-10-19 12:41:34'),
(10, 'Clement Swarnappa', 'Please ignore this registration.  This is part of the User Interface Testing, I am doing for the stu', 'clement.sudhakar@gmail.com', '048303130', 10, '2019-10-21 10:42:45'),
(11, 'a', '', 'hghghghghg@kjkj.com', '0909090909', 4, '2019-10-23 14:55:09');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
